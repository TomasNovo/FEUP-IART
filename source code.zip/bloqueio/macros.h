#ifndef MACROS_H
#define MACROS_H


#define DEBUG 0

#define MAPHEIGHT 9
#define MAPWIDTH 9

#define MAXWALLCOUNT 5

#define MINIMAXDEPTH 1


#endif